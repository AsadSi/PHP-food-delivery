
##############################
Tailwindcss
- move to the tailwindcss folder from htdocs
  cd tailwindcss

- If you git clone or git pull, make sure you have 
- the node_modules in the tailwindcss folder. If the node_modules
- is not there, then run this command

  npm install -D tailwindcss
  npx tailwindcss -i ./input.css -o ../app.css --watch


##############################
Faker
https://github.com/fzaninotto/Faker


##############################
git add .
git stash
git pull







